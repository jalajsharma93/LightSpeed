<?php
session_start();
require('connection.php');
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}
include_once('head.php');
?>


<div class="content">

  <div class="row">

    <?php 

$stmt= $con->prepare('SELECT project_name,hours from project where project_id=?');
$stmt->bind_param('i', $_GET['p_id']);
$stmt->execute();
$stmt->bind_result($pname,$hours);
$stmt->fetch();

?>

    <div class="col-md-6">
      <h1> <?php echo $pname;?></h1>
    </div>

    <div class="col-md-6">
      <h1 style="float:right"> <?php echo $hours." hours";?></h1>
    </div>
    <?php
    $stmt->close();
    ?>
    <div class="col-md-12">
      <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Task Name</th>
            <th scope="col"> Assigned To </th>
            <th scope="col">Estimated Hours</th>

          </tr>
        </thead>
        <tbody>

          <?php
        $p =  $_GET['p_id'];
        $stmt1 = $con->prepare('SELECT taskname,tasks.hours,username from tasks,project,users where tasks.eid = users.id AND tasks.pid= project.project_id AND project.project_id =?');
        $stmt1->bind_param('i', $p);
        $stmt1->execute();

            $stmt1->bind_result($taskname,$hours,$username);
            $i = 0;
           while( $stmt1->fetch()) {

        ?>


          <tr>
            <th scope="row"><?php echo ++$i ;?></th>
            <td><?php echo $taskname; ?> </td>
            <td> <?php echo $username; ?> </td>
            <td> <?php echo $hours; ?> </td>
          </tr>




          <?php 
  
        }

        $stmt1->close();
  ?>
        </tbody>
      </table>

      <button onclick="goBack()" class="btn btn-outline-primary">Go Back</button>
    </div>
  </div>

  <?php include_once('footer.php'); ?>