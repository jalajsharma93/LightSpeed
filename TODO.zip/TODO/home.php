<?php
session_start();
require('connection.php');
//Check Session login
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}
include_once('head.php');
?>


<div class="content">


  <p>Welcome back, <?=$_SESSION['name']?>! <button style=" float:right" class="btn btn-outline-primary"
      data-toggle="modal" data-target="#exampleModal"> Add Project</button>
  </p>


  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Project Name</th>
        <th scope="col">Estimated Hours</th>
        <th scope="col">Team Members</th>
        <th scope="col">Add Tasks</th>

      </tr>
    </thead>
    <tbody>

      <?php

        $stmt = $con->prepare('SELECT project_id,project_name,hours from project');
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($project_id,$project_name,$hours);
        $i = 0;

        while( $stmt->fetch()) {

            $stm = $con->prepare("SELECT GROUP_CONCAT( DISTINCT users.username ORDER BY users.username ASC SEPARATOR ' , ') 
            from users,project,tasks where project.project_id=tasks.pid AND tasks.eid = users.id AND project.project_id=?");
            $stm->bind_param('i',$project_id);
            $stm->execute();
            $stm->bind_result($username);
            $stm->fetch();

    ?>

      <!--TO add Task-->
      <tr>
        <th scope="row"><?php echo ++$i ;?></th>
        <td><?php echo $project_name; ?> </td>
        <td><?php echo $hours; ?> </td>
        <td><?php echo $username;  ?> </td>
        <td><a href="addtask.php?p_id=<?php echo $project_id; ?>" class="btn btn-outline-primary"> Assign Task</a></td>
      </tr>




      <?php 
           
               
           $stm->close();
        }

        $stmt->close();
  ?>
    </tbody>
  </table>
</div>

<!-- Bootstrap Model for and Add Project  -->
<div class="modal fade" id="exampleModal" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog"
  aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Project</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <form method="post" action="addProject.php">
        <div class="modal-body">

          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="projecName">Project Name</label>
              <input type="text" class="form-control" name="pname" required>
            </div>

            <input type="submit" name="addproject" class="btn btn-primary" value="Add Project">

          </div>
      </form>

    </div>
  </div>
</div>


</div>
<!--For Regiter USER-->
<div class="modal fade" id="exampleModal1" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog"
  aria-labelledby="exampleModalLabel1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel1">Register New User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <!--TO send data from Register file-->
      <form action="register.php" method="post" autocomplete="off">
        <div class="modal-body">
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="username">
                Username
              </label>
              <input type="text" name="username" placeholder="Username" class="form-control" id="username" required>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="password">
                Password
              </label>
              <input type="password" name="password" placeholder="Password" class="form-control" id="password" required>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="email">
                Email
              </label>
              <input type="email" name="email" class="form-control" placeholder="Email" id="email" required>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="user">
                Role
              </label>
              <select name="user" required class="form-control">
                <option value="" selected> Choose one</option>
                <option value="1"> Admin</option>
                <option value="2"> Team Member</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group col-md-12">
              <input style="width:100%" type="submit" value="Register" class="btn btn-primary">
            </div>
          </div>
        </div>
      </form>

    </div>
  </div>
</div>

</div>

<?php include_once('footer.php'); ?>