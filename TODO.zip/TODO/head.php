<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<title>Home Page</title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	<link href="assests/css/style.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
		integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
</head>

<body class="loggedin">
	<nav class="navtop">
		<div>
			<h1>ToDo List</h1>
			<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
			<button class="btn btn-outline-primary" data-toggle="modal" data-target="#exampleModal1"> Register
				User</button>
		</div>
	</nav>